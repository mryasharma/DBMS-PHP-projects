# Labour Management System (PHP + MySQL)
A system for managing contractors, supervisors, and workers with role-based access.

## Features
- Role-based login (Contractor, Supervisor, Worker)
- Add workers, manage records, and view expenses
- Email-based credential sending

## Tech Stack
PHP, MySQL, HTML, CSS, XAMPP
