# Bank Locker Management System (PHP + MySQL)
A secure locker management web app for banks, allowing users and admins to manage locker details.

## Features
- Login/Logout system
- Locker registration & tracking
- Admin panel for user management
- MySQL database integration

## Tech Stack
PHP, MySQL, HTML, CSS, XAMPP
