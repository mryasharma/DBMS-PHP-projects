# E-Commerce Website (PHP + MySQL)
An online store allowing users to browse, add to cart, and checkout products.

## Features
- User registration & login
- Product listing with images and prices
- Add to cart, remove, and checkout
- Admin panel for product management

## Tech Stack
PHP, MySQL, HTML, CSS, Bootstrap
