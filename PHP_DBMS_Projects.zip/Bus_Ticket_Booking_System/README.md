# Bus Ticket Booking System (PHP + MySQL)
A web platform for booking bus tickets online.

## Features
- Search buses, view available seats
- Ticket booking & cancellation
- Admin panel for managing routes and buses

## Tech Stack
PHP, MySQL, HTML, CSS, Bootstrap
